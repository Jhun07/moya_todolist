<?php
	include_once('database.php');
	if(ISSET($_POST['add'])){
		if($_POST['task'] != ""){
			$task = $_POST['task'];
 
			$conn->query("INSERT INTO `records` VALUES('', '$task', '')");
			header('location:index.php');
		}
	}
?>



