<?php
	require_once 'database.php';
 
	if($_GET['id']){
		$id = $_GET['id'];
        if(isset($_REQUEST['id'])){

			$id=$_REQUEST['id'];
			$query=mysqli_query($conn, "SELECT * FROM `records` WHERE `id` = '$id'") or die(mysqli_error());
			$fetch=mysqli_fetch_array($query);	
			
		}

		$conn->query("INSERT INTO `trash` VALUES('','$fetch[name]')") or die(mysqli_errno($conn));
		$conn->query("DELETE FROM `records` WHERE `id` = $id") or die(mysqli_errno($conn));
		header("location: index.php");
	}	