<?php
    
    include('database.php');
    
    if(ISSET($_REQUEST['task_id'])){
        $task_id = $_REQUEST['task_id'];
        $query=mysqli_query($conn, "SELECT * FROM `trash` WHERE `task_id` = '$task_id'") or die(mysqli_error());
        $fetch=mysqli_fetch_array($query);  
        
        mysqli_query($conn, "DELETE FROM `trash` WHERE `task_id` = '$task_id'") or die(mysqli_error());
        mysqli_query($conn, "INSERT INTO `records` VALUES('', '$fetch[task]', '')");
        header('location:trash.php');
    }
    else{
        die(mysqli_error());
    }

    
?>
