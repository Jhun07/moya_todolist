<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <style>
    * {
        box-sizing: border-box;
        margin-left: 10%;
        margin-right: 10%;
    }

  

    form {
        border-radius: 5px;
        padding: 5px;
        background:  #4e73df;
}

    input[type=text],
    input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        display: inline-block;
        
    }

    label {
        border: #40E0D0;
    }

    input[type=text]:focus,
    input[type=password]:focus {
        background-color: #ddd;
        outline: none;
    }




    .button {
        background-color:  white;
        border: inset;
        color: Black;
        padding: 15px;
        width: 40%;
        text-align: center;
        text-decoration: fantasy;
        display: inline-block;
        font-size: 20px blue;
        margin: 4px 2px;
        margin-left: 5%;
        transition-duration: 0.4s;
        cursor: pointer;
    }

    
    </style>
</head>

<body>
    <div class="container">


        <?php
                    include "database.php"; // Using database connection file here
                    
                    
                    if(isset($_POST['update'])) // when click on Update button
                    {
                        $id = $_POST['id'];
                        $name = $_POST['newT'];
                        $edit=$conn->query("UPDATE `records` set name='$name' where id='$id'");
                        
                        if($edit)
                        {
                            header("location:index.php"); // redirects to all records page
                            exit;
                        }
                        else
                        {
                            echo mysqli_error();
                        }    	
                    }





				?>
        <?php
                $id = $_GET['id']; // get id through query string
                $qry = mysqli_query($conn,"SELECT * from records where id='$id'"); // select query
                    // fetch data
                while( $data = mysqli_fetch_array($qry)){
             ?>
        <form style="margin-top:  10%" method="POST">
            <label for="firstname"><b>Task ID</b></label>
            <input type="text" name="id" placeholder="Updated task" value="<?php echo $data['id']?>" readonly>
            <label for="firstname"><b>Enter your task</b></label>
            <input type="text" name="newT" placeholder="Updated task" value="<?php echo $data['name']?>" Required>
            <button type="submit" name="update" class="button"><i class=' fas fa-check '></i>
            <button type="submit" name="cancel" class="button" ><a  href="index.php"><i class=' fas fa-times '></i></a>


            <?php
					
				}?>


        </form>
    </div>
</body>

</html>